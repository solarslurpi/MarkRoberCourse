                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:708819
Mini Pan Tilt - Servo G9 by fbuenonet is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

English  

Pant Tilt small size for use with small format cameras. Is mounted on and G9 micro servos can be used as a drone or surveillance camera support.  

Does not incorporate any restraint of the camera, but you can use double sided tape or Velcro tape.  

It is also possible to paste on camera platform support for GoPro's cablecam http://www.thingiverse.com/thing:391146 and use the bumper http://www.thingiverse.com/thing:462309 as restraint GoPro camera  

If you find my design interesting, you could make a small donation: https://www.paypal.me/fbuenonet

Español  

Pant Tilt de reducidas dimensiones para utilizar con cámaras de pequeño formato. Se monta sobre micro servos G9 y puede ser utilizado en un drone o como soporte de cámara de vigilancia.  

No incorpora ningún sistema de sujeción de la cámara, pero se puede usar cinta adhesiva de doble cara o cinta Velcro.  

También es posible pegar sobre la plataforma de la cámara el soporte para GoPro del cablecam http://www.thingiverse.com/thing:391146 y usar el bumper http://www.thingiverse.com/thing:462309 como sistema de sujeción de la cámara GoPro

Si te parece interesante mi diseño, podrías hacer un pequeño donativo: https://www.paypal.me/fbuenonet